import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertSubscriptionSchema, type Subscription, type InsertSubscription } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatPrice, normalizeFormPrice, normalizeStoredPrice } from "@/lib/priceUtils";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Form schema with string price for natural decimal entry
const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  price: z.string().min(1, "Price is required"),
  period: z.enum(["monthly", "annual"]),
  nextBilling: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Must be valid ISO date (YYYY-MM-DD)"),
  vibe: z.enum(["Secure", "Clear", "Empowering"]),
  category: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

interface AddEditSubscriptionModalProps {
  subscription: Subscription | null;
  onClose: () => void;
}

function addDays(days: number): string {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date.toISOString().slice(0, 10);
}

export function AddEditSubscriptionModal({
  subscription,
  onClose,
}: AddEditSubscriptionModalProps) {
  const { toast } = useToast();
  const isEditing = !!subscription;

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: subscription ? {
      name: subscription.name,
      price: formatPrice(subscription.price),
      period: subscription.period,
      nextBilling: subscription.nextBilling,
      vibe: subscription.vibe,
      category: subscription.category,
    } : {
      name: "",
      price: "",
      period: "monthly",
      nextBilling: addDays(30),
      vibe: "Clear",
      category: "Other",
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertSubscription) =>
      apiRequest("POST", "/api/subscriptions", data),
    onMutate: async (newSub) => {
      await queryClient.cancelQueries({ queryKey: ["/api/subscriptions"] });
      const previousSubs = queryClient.getQueryData(["/api/subscriptions"]);
      
      queryClient.setQueryData(["/api/subscriptions"], (old: Subscription[] | undefined) => {
        const tempSub = { ...newSub, id: `temp-${Date.now()}`, price: normalizeStoredPrice(newSub.price) };
        return old ? [tempSub, ...old] : [tempSub];
      });
      
      return { previousSubs };
    },
    onError: (_error, _variables, context) => {
      if (context?.previousSubs) {
        queryClient.setQueryData(["/api/subscriptions"], context.previousSubs);
      }
      toast({
        title: "Error",
        description: "Failed to add subscription",
        variant: "destructive",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscriptions"] });
      toast({
        title: "Subscription added",
        description: "Your subscription has been added successfully",
      });
      onClose();
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data: InsertSubscription) =>
      apiRequest("PATCH", `/api/subscriptions/${subscription?.id}`, data),
    onMutate: async (updatedData) => {
      await queryClient.cancelQueries({ queryKey: ["/api/subscriptions"] });
      const previousSubs = queryClient.getQueryData(["/api/subscriptions"]);
      
      queryClient.setQueryData(["/api/subscriptions"], (old: Subscription[] | undefined) => {
        if (!old) return old;
        return old.map((sub) =>
          sub.id === subscription?.id
            ? { ...sub, ...updatedData, price: normalizeStoredPrice(updatedData.price) }
            : sub
        );
      });
      
      return { previousSubs };
    },
    onError: (_error, _variables, context) => {
      if (context?.previousSubs) {
        queryClient.setQueryData(["/api/subscriptions"], context.previousSubs);
      }
      toast({
        title: "Error",
        description: "Failed to update subscription",
        variant: "destructive",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscriptions"] });
      toast({
        title: "Subscription updated",
        description: "Your changes have been saved",
      });
      onClose();
    },
  });

  const onSubmit = (values: FormValues) => {
    // Convert form values to API format
    const price = normalizeFormPrice(values.price);
    if (price === undefined || price <= 0) {
      form.setError("price", { message: "Price must be a positive number" });
      return;
    }

    const apiData: InsertSubscription = {
      ...values,
      price,
    };

    if (isEditing) {
      updateMutation.mutate(apiData);
    } else {
      createMutation.mutate(apiData);
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Subscription" : "Add Subscription"}</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Service Name</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="e.g., Netflix"
                        data-testid="input-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="price"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Price (₹)</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="number"
                        step="0.01"
                        min="0"
                        placeholder="649.00"
                        data-testid="input-price"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="period"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Billing Period</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-period">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="monthly">Monthly</SelectItem>
                        <SelectItem value="annual">Annual</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="nextBilling"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Next Billing Date</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="date"
                        data-testid="input-next-billing"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="vibe"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vibe</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-vibe">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Clear">Clear</SelectItem>
                        <SelectItem value="Secure">Secure</SelectItem>
                        <SelectItem value="Empowering">Empowering</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-category">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Entertainment">Entertainment</SelectItem>
                        <SelectItem value="Health">Health</SelectItem>
                        <SelectItem value="Productivity">Productivity</SelectItem>
                        <SelectItem value="Education">Education</SelectItem>
                        <SelectItem value="Utilities">Utilities</SelectItem>
                        <SelectItem value="Software">Software</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isPending}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isPending} data-testid="button-submit">
                {isPending
                  ? isEditing
                    ? "Updating..."
                    : "Adding..."
                  : isEditing
                  ? "Update subscription"
                  : "Add subscription"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
