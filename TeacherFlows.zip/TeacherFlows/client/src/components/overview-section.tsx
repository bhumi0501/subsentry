import type { Subscription } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { parsePrice, formatPrice } from "@/lib/priceUtils";

interface OverviewSectionProps {
  subscriptions: Subscription[];
  isLoading: boolean;
  onAddClick: () => void;
}

function daysUntil(isoDate: string): number {
  // Parse YYYY-MM-DD as local date to avoid timezone issues
  const [year, month, day] = isoDate.split('-').map(Number);
  const target = new Date(year, month - 1, day);
  target.setHours(0, 0, 0, 0);
  
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  
  const diff = target.getTime() - now.getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24));
}

export function OverviewSection({ subscriptions, isLoading, onAddClick }: OverviewSectionProps) {
  const monthlyTotal = subscriptions.reduce((acc, sub) => {
    const price = parsePrice(sub.price);
    return acc + (sub.period === "monthly" ? price : price / 12);
  }, 0);

  const annualTotal = subscriptions.reduce((acc, sub) => {
    const price = parsePrice(sub.price);
    return acc + (sub.period === "annual" ? price : price * 12);
  }, 0);

  const upcomingRenewals = subscriptions
    .filter((sub) => {
      const days = daysUntil(sub.nextBilling);
      return days >= 0 && days <= 7;
    })
    .sort((a, b) => daysUntil(a.nextBilling) - daysUntil(b.nextBilling));

  if (isLoading) {
    return (
      <div className="bg-card p-4 rounded-2xl border border-card-border">
        <Skeleton className="h-8 w-32 mb-4" />
        <div className="space-y-3">
          <Skeleton className="h-24 rounded-lg" />
          <Skeleton className="h-32 rounded-lg" />
        </div>
      </div>
    );
  }

  return (
    <section className="bg-card p-4 rounded-2xl border border-card-border">
      <h3 className="text-lg font-semibold mb-3">Overview</h3>
      <div className="space-y-3">
        {/* Monthly Spend Summary */}
        <div className="p-3 rounded-lg bg-gradient-to-r from-primary/10 to-card">
          <div className="text-sm text-muted-foreground">Estimated monthly spend</div>
          <div className="text-2xl font-bold" data-testid="text-monthly-total">
            ₹{formatPrice(monthlyTotal)}
          </div>
          <div className="text-xs text-muted-foreground">
            Annualized: ₹{formatPrice(annualTotal)}
          </div>
        </div>

        {/* Upcoming Renewals */}
        <div className="p-3 rounded-lg bg-card border border-border">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="text-sm text-muted-foreground">Upcoming renewals</div>
              <div className="text-lg font-medium" data-testid="text-upcoming-count">
                {upcomingRenewals.length} in 7 days
              </div>
            </div>
            <Button onClick={onAddClick} size="sm" data-testid="button-add-sidebar">
              Add
            </Button>
          </div>
          <ul className="space-y-2">
            {upcomingRenewals.slice(0, 3).map((sub) => (
              <li
                key={sub.id}
                className="flex items-center justify-between text-sm"
                data-testid={`upcoming-${sub.id}`}
              >
                <div>
                  {sub.name} • ₹{formatPrice(sub.price)}
                </div>
                <div className="text-xs text-muted-foreground">
                  in {daysUntil(sub.nextBilling)}d
                </div>
              </li>
            ))}
            {upcomingRenewals.length === 0 && (
              <li className="text-sm text-muted-foreground">
                Nothing soon — good job!
              </li>
            )}
          </ul>
        </div>
      </div>
    </section>
  );
}
