import type { Subscription } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatPrice } from "@/lib/priceUtils";
import { Pencil, Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface SubscriptionCardProps {
  subscription: Subscription;
  onEdit: (subscription: Subscription) => void;
}

const VIBE_STYLES = {
  Secure: {
    card: "bg-teal-50 ring-2 ring-teal-200/60 dark:bg-teal-950/20 dark:ring-teal-800/60",
    badge: "bg-teal-100 text-teal-800 dark:bg-teal-900/40 dark:text-teal-300",
  },
  Clear: {
    card: "bg-indigo-50 ring-2 ring-indigo-200/60 dark:bg-indigo-950/20 dark:ring-indigo-800/60",
    badge: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/40 dark:text-indigo-300",
  },
  Empowering: {
    card: "bg-violet-50 ring-2 ring-violet-200/60 dark:bg-violet-950/20 dark:ring-violet-800/60",
    badge: "bg-violet-100 text-violet-800 dark:bg-violet-900/40 dark:text-violet-300",
  },
};

function daysUntil(isoDate: string): number {
  // Parse YYYY-MM-DD as local date to avoid timezone issues
  const [year, month, day] = isoDate.split('-').map(Number);
  const target = new Date(year, month - 1, day);
  target.setHours(0, 0, 0, 0);
  
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  
  const diff = target.getTime() - now.getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24));
}

export function SubscriptionCard({ subscription, onEdit }: SubscriptionCardProps) {
  const { toast } = useToast();
  const vibeStyle = VIBE_STYLES[subscription.vibe] || VIBE_STYLES.Clear;

  const markPaidMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("PATCH", `/api/subscriptions/${subscription.id}/mark-paid`, {});
    },
    onMutate: async () => {
      // Optimistic update
      await queryClient.cancelQueries({ queryKey: ["/api/subscriptions"] });
      const previousSubs = queryClient.getQueryData(["/api/subscriptions"]);
      
      queryClient.setQueryData(["/api/subscriptions"], (old: Subscription[] | undefined) => {
        if (!old) return old;
        return old.map((sub) => {
          if (sub.id === subscription.id) {
            const currentDate = new Date(sub.nextBilling);
            if (sub.period === "monthly") {
              currentDate.setMonth(currentDate.getMonth() + 1);
            } else {
              currentDate.setFullYear(currentDate.getFullYear() + 1);
            }
            return { ...sub, nextBilling: currentDate.toISOString().slice(0, 10) };
          }
          return sub;
        });
      });
      
      return { previousSubs };
    },
    onError: (_error, _variables, context) => {
      // Rollback on error
      if (context?.previousSubs) {
        queryClient.setQueryData(["/api/subscriptions"], context.previousSubs);
      }
      toast({
        title: "Error",
        description: "Failed to mark subscription as paid",
        variant: "destructive",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscriptions"] });
      toast({
        title: "Marked as paid",
        description: `Next billing date updated for ${subscription.name}`,
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: () => apiRequest("DELETE", `/api/subscriptions/${subscription.id}`),
    onMutate: async () => {
      // Optimistic update
      await queryClient.cancelQueries({ queryKey: ["/api/subscriptions"] });
      const previousSubs = queryClient.getQueryData(["/api/subscriptions"]);
      
      queryClient.setQueryData(["/api/subscriptions"], (old: Subscription[] | undefined) => {
        if (!old) return old;
        return old.filter((sub) => sub.id !== subscription.id);
      });
      
      return { previousSubs };
    },
    onError: (_error, _variables, context) => {
      // Rollback on error
      if (context?.previousSubs) {
        queryClient.setQueryData(["/api/subscriptions"], context.previousSubs);
      }
      toast({
        title: "Error",
        description: "Failed to delete subscription",
        variant: "destructive",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscriptions"] });
      toast({
        title: "Subscription deleted",
        description: `${subscription.name} has been removed`,
      });
    },
  });

  return (
    <div
      className={`p-4 rounded-2xl ${vibeStyle.card}`}
      data-testid={`card-subscription-${subscription.id}`}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="text-lg font-semibold truncate" data-testid={`text-name-${subscription.id}`}>
              {subscription.name}
            </h3>
            <Badge className={`${vibeStyle.badge} text-xs`} data-testid={`badge-vibe-${subscription.id}`}>
              {subscription.vibe}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            {subscription.category} • Next: {subscription.nextBilling}
          </p>
        </div>
        <div className="text-right">
          <div className="text-lg font-bold" data-testid={`text-price-${subscription.id}`}>
            ₹{formatPrice(subscription.price)}
          </div>
          <div className="text-xs text-muted-foreground">{subscription.period}</div>
        </div>
      </div>

      <div className="flex items-center justify-between text-sm gap-2">
        <div className="flex items-center gap-2">
          <Button
            onClick={() => markPaidMutation.mutate()}
            disabled={markPaidMutation.isPending}
            variant="outline"
            size="sm"
            className="text-xs h-8"
            data-testid={`button-mark-paid-${subscription.id}`}
          >
            {markPaidMutation.isPending ? "Updating..." : "Mark paid"}
          </Button>
          <Button
            onClick={() => onEdit(subscription)}
            variant="outline"
            size="sm"
            className="text-xs h-8 px-2"
            data-testid={`button-edit-${subscription.id}`}
          >
            <Pencil className="w-3 h-3" />
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="text-xs h-8 px-2 text-destructive hover:text-destructive"
                data-testid={`button-delete-${subscription.id}`}
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Remove subscription?</AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to remove "{subscription.name}"? This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => deleteMutation.mutate()}
                  disabled={deleteMutation.isPending}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  data-testid={`button-confirm-delete-${subscription.id}`}
                >
                  {deleteMutation.isPending ? "Deleting..." : "Delete"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
        <div className="text-xs text-muted-foreground" data-testid={`text-days-${subscription.id}`}>
          in {daysUntil(subscription.nextBilling)} days
        </div>
      </div>
    </div>
  );
}
