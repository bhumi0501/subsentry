/**
 * Price utility functions for consistent decimal handling across the app
 */

/**
 * Parse a price value (string or number) to a number for calculations
 */
export function parsePrice(price: string | number): number {
  if (typeof price === "number") return price;
  const parsed = parseFloat(price);
  return isNaN(parsed) ? 0 : parsed;
}

/**
 * Format a price for display with two decimal places
 */
export function formatPrice(price: string | number): string {
  return parsePrice(price).toFixed(2);
}

/**
 * Normalize a price for storage (convert number to string with 2 decimals)
 */
export function normalizeStoredPrice(price: number): string {
  return price.toFixed(2);
}

/**
 * Normalize a form price string to a number, handling empty/invalid values
 * Returns undefined for invalid input (to trigger validation errors)
 */
export function normalizeFormPrice(priceStr: string): number | undefined {
  if (priceStr === "" || priceStr === null || priceStr === undefined) {
    return undefined;
  }
  const parsed = parseFloat(priceStr);
  return isNaN(parsed) ? undefined : parsed;
}
