import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import type { Subscription } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, User } from "lucide-react";
import { SubscriptionCard } from "@/components/subscription-card";
import { AddEditSubscriptionModal } from "@/components/add-edit-subscription-modal";
import { OverviewSection } from "@/components/overview-section";
import { Alert, AlertDescription } from "@/components/ui/alert";

const VIBE_FILTERS = [
  { value: "all", label: "All vibes" },
  { value: "Secure", label: "Secure" },
  { value: "Clear", label: "Clear" },
  { value: "Empowering", label: "Empowering" },
];

export default function Dashboard() {
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingSubscription, setEditingSubscription] = useState<Subscription | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [vibeFilter, setVibeFilter] = useState("all");
  const [username, setUsername] = useState<string>(() => {
    return localStorage.getItem("subsentry_username") || "";
  });
  const [showUsernamePrompt, setShowUsernamePrompt] = useState(!username);

  useEffect(() => {
    if (username) {
      localStorage.setItem("subsentry_username", username);
    }
  }, [username]);

  const { data: subscriptions = [], isLoading, isError } = useQuery<Subscription[]>({
    queryKey: ["/api/subscriptions"],
  });

  const filteredSubscriptions = subscriptions.filter((sub) => {
    const matchesSearch = sub.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesVibe = vibeFilter === "all" || sub.vibe === vibeFilter;
    return matchesSearch && matchesVibe;
  });

  const handleOpenAddModal = () => {
    setEditingSubscription(null);
    setShowAddModal(true);
  };

  const handleOpenEditModal = (subscription: Subscription) => {
    setEditingSubscription(subscription);
    setShowAddModal(true);
  };

  const handleCloseModal = () => {
    setShowAddModal(false);
    setEditingSubscription(null);
  };

  const handleUsernameSubmit = (name: string) => {
    if (name.trim()) {
      setUsername(name.trim());
      setShowUsernamePrompt(false);
    }
  };

  const handleChangeUsername = () => {
    const newName = prompt("Enter your name:", username);
    if (newName && newName.trim()) {
      setUsername(newName.trim());
    }
  };

  if (showUsernamePrompt) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-card p-8 rounded-2xl border border-card-border">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-extrabold text-primary mb-2">SubSentry</h1>
            <p className="text-muted-foreground">Track your subscriptions with ease</p>
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              const name = formData.get("username") as string;
              handleUsernameSubmit(name);
            }}
            className="space-y-4"
          >
            <div>
              <label htmlFor="username" className="block text-sm font-medium mb-2">
                What's your name?
              </label>
              <Input
                id="username"
                name="username"
                placeholder="Enter your name"
                autoFocus
                required
                data-testid="input-username"
              />
            </div>
            <Button type="submit" className="w-full" data-testid="button-start">
              Get Started
            </Button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <header className="max-w-5xl mx-auto flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <h1 className="text-2xl font-extrabold text-primary">SubSentry</h1>
          <div className="text-sm text-muted-foreground">Subscription Tracker</div>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-sm text-foreground flex items-center gap-2">
            <User className="w-4 h-4" />
            <span className="font-medium">{username}</span>
          </div>
          <Button
            onClick={handleChangeUsername}
            variant="outline"
            size="sm"
            data-testid="button-change-username"
          >
            Change
          </Button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Sidebar: Overview + Upcoming Renewals */}
        <aside className="md:col-span-1">
          <OverviewSection
            subscriptions={subscriptions}
            isLoading={isLoading}
            onAddClick={handleOpenAddModal}
          />
        </aside>

        {/* Right Area: Search + Filters + Subscription Grid */}
        <section className="md:col-span-2 bg-card rounded-2xl p-4 border border-card-border">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Subscriptions</h2>
            <p className="text-sm text-muted-foreground">Manage recurring charges</p>
          </div>

          {/* Search and Filters */}
          <div className="flex gap-3 items-center mb-4">
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search subscriptions"
              className="flex-1"
              data-testid="input-search"
            />
            <Select value={vibeFilter} onValueChange={setVibeFilter}>
              <SelectTrigger className="w-40" data-testid="select-vibe-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {VIBE_FILTERS.map((filter) => (
                  <SelectItem key={filter.value} value={filter.value}>
                    {filter.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={handleOpenAddModal} className="gap-2" data-testid="button-add-subscription">
              <Plus className="w-4 h-4" />
              Add
            </Button>
          </div>

          {/* Subscription Grid */}
          {isError ? (
            <Alert variant="destructive">
              <AlertDescription>
                Failed to load subscriptions. Please refresh the page to try again.
              </AlertDescription>
            </Alert>
          ) : isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-40 rounded-2xl" />
              ))}
            </div>
          ) : filteredSubscriptions.length === 0 ? (
            <div className="p-12 text-center">
              <p className="text-muted-foreground mb-4">
                {searchQuery || vibeFilter !== "all"
                  ? "No subscriptions found. Try adjusting your filters."
                  : "No subscriptions yet. Add one to get started!"}
              </p>
              <Button onClick={handleOpenAddModal} variant="outline" data-testid="button-add-first">
                <Plus className="w-4 h-4 mr-2" />
                Add your first subscription
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {filteredSubscriptions.map((subscription) => (
                <SubscriptionCard
                  key={subscription.id}
                  subscription={subscription}
                  onEdit={handleOpenEditModal}
                />
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Footer Tip */}
      <footer className="max-w-5xl mx-auto mt-6 p-4 text-sm text-muted-foreground">
        <strong>Tip:</strong> Use vibe tags to prioritize cancellations — Secure = essential,
        Clear = review, Empowering = optional growth tools.
      </footer>

      {/* Add/Edit Modal */}
      {showAddModal && (
        <AddEditSubscriptionModal
          subscription={editingSubscription}
          onClose={handleCloseModal}
        />
      )}
    </div>
  );
}
