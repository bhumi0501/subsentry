# SubSentry - Subscription Tracker

## Overview

SubSentry is a subscription tracking application that helps users monitor and manage their recurring subscriptions. The application features a unique "vibe-coded" categorization system that organizes subscriptions into three categories: Secure (essential services), Clear (review recommended), and Empowering (optional growth). Users can track spending, receive renewal alerts, and visualize their subscription commitments through a clean, fintech-inspired dashboard interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18+ with TypeScript, bundled using Vite as the build tool and development server.

**UI Component Library**: Radix UI primitives wrapped with shadcn/ui components, providing accessible, customizable components with consistent styling through TailwindCSS.

**State Management**: 
- TanStack Query (React Query) for server state management, data fetching, and caching
- Local React state for UI interactions and form management
- LocalStorage for username persistence

**Form Handling**: React Hook Form with Zod schema validation for type-safe form data validation and submission.

**Routing**: Wouter for lightweight client-side routing (single-page application).

**Design System**:
- Vibe-based color categorization (Secure/teal, Clear/indigo, Empowering/violet)
- TailwindCSS for utility-first styling with custom theme configuration
- System font stack for typography
- Responsive layout with mobile-first approach

### Backend Architecture

**Runtime**: Node.js with Express.js framework for RESTful API endpoints.

**API Design**: RESTful endpoints following standard HTTP methods:
- GET /api/subscriptions - Retrieve all subscriptions
- POST /api/subscriptions - Create new subscription
- PATCH /api/subscriptions/:id - Update existing subscription
- DELETE /api/subscriptions/:id - Remove subscription

**Data Validation**: Zod schemas shared between frontend and backend for consistent validation rules.

**Storage Interface**: Abstract IStorage interface allowing flexible storage implementation (currently using in-memory storage with sample data for development).

**Middleware**:
- JSON body parsing with raw body preservation for webhook support
- Request logging middleware for API endpoint monitoring
- Vite development middleware for HMR (Hot Module Replacement) in development

### Data Storage

**ORM**: Drizzle ORM configured for PostgreSQL with type-safe database operations.

**Schema Design**:
- Subscriptions table with fields: id (UUID), name, price (decimal), period (monthly/annual), nextBilling (ISO date), vibe (enum), category
- Decimal precision handling for accurate financial calculations
- Enum-based validation for period and vibe fields

**Database Provider**: Neon serverless PostgreSQL (configured but not yet connected in development environment).

**Migration System**: Drizzle Kit for schema migrations with output directory at ./migrations.

**Development Mode**: In-memory storage (MemStorage class) with seeded sample data for rapid development without database dependency.

### External Dependencies

**Database**: 
- Neon Serverless PostgreSQL (@neondatabase/serverless) - cloud-hosted PostgreSQL database
- Connection via DATABASE_URL environment variable

**UI Components**:
- Radix UI component primitives for accessible, unstyled UI components
- shadcn/ui component library built on Radix UI
- Lucide React for icon components

**Utilities**:
- date-fns for date manipulation and formatting
- class-variance-authority for component variant styling
- clsx and tailwind-merge for conditional className management

**Development Tools**:
- Replit-specific plugins for development banner, cartographer, and error overlay
- TypeScript for type safety across the stack
- ESBuild for production server bundling

**Design Reference**: The application draws inspiration from modern fintech dashboards (Mint, YNAB) combined with productivity tools (Notion) for clean data visualization.