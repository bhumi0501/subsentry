import { decimal, pgTable, text, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const subscriptions = pgTable("subscriptions", {
  id: varchar("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  name: text("name").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  period: text("period", { enum: ["monthly", "annual"] }).notNull(),
  nextBilling: text("next_billing").notNull(),
  vibe: text("vibe", { enum: ["Secure", "Clear", "Empowering"] }).notNull(),
  category: text("category").notNull(),
});

const VALID_CATEGORIES = [
  "Entertainment",
  "Health",
  "Productivity",
  "Education",
  "Utilities",
  "Software",
  "Other",
] as const;

export const insertSubscriptionSchema = createInsertSchema(subscriptions)
  .omit({ id: true })
  .extend({
    price: z.coerce.number().positive("Price must be positive"),
    nextBilling: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Must be valid ISO date (YYYY-MM-DD)"),
    category: z.enum(VALID_CATEGORIES, {
      errorMap: () => ({ message: "Category must be one of: " + VALID_CATEGORIES.join(", ") }),
    }),
  });

export const updateSubscriptionSchema = insertSubscriptionSchema.partial();

export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type UpdateSubscription = z.infer<typeof updateSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;
